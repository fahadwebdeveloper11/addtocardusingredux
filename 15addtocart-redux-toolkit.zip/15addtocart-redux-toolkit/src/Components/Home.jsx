import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addToCart } from "../Store/cartSlice";
import { Products } from "../Store/products";
import { ToastContainer, toast } from "react-toastify";

const Home = () => {
  const product = Products;

  const dispatch = useDispatch();

  const handleClick = (product) => {
    dispatch(addToCart(product));
  };


  return (
    <>
      <section className="text-gray-400 bg-gray-900 body-font">
        <div className="container px-5 py-24 mx-auto">
          <div className="flex flex-wrap -m-4">
            {product.map((products) => {
              // console.log(products.image)
              return (
                <div key={products.id} className="lg:w-1/4 md:w-1/2 p-4 w-full">
                  <a className="block relative h-48 rounded overflow-hidden">
                    <img
                      alt="ecommerce"
                      className="object-cover object-top w-full h-full block"
                      src={products.image}
                    />
                  </a>
                  <div className="mt-4">
                    {/* <h3 className="text-gray-500 text-xs tracking-widest title-font mb-1">
                    CATEGORY
                  </h3> */}
                    <h2 className="text-white title-font text-lg font-medium">
                      {products.title}
                    </h2>
                    <p className="mt-1 mb-2">${products.price}</p>
                    <button
                      className=" text-white bg-indigo-500 border-0 py-2 px-8 focus:outline-none hover:bg-indigo-600 rounded text-base mt-10 sm:mt-0"
                      onClick={() => handleClick(products)}
                    >
                      Add Cart
                    </button>
                    <ToastContainer />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>
  
    </>
  );
};

export default Home;
