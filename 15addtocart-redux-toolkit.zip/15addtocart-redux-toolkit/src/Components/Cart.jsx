import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  deleteItem,
  increaseQty,
  decreaseQty,
  calculateTotal,
} from "../Store/cartSlice";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Cart = () => {
  const products = useSelector((state) => state.cart);
  // console.log(products);

  const dispatch = useDispatch();

  const deleteHandler = (product) => {
    dispatch(deleteItem(product));
  };

  const increaseQtyHandle = (product) => {
    dispatch(increaseQty(product));
  };
  const decreaseQtyHandle = (product) => {
    dispatch(decreaseQty(product));
  };

  useEffect(() => {
    dispatch(calculateTotal());
  }, [products]);

  return (
    <>
      <div
        id="carty"
        className="flex items-start justify-between w-full h-[80vh]"
      >
        <div className="w-full h-full no-scrollbar overflow-y-auto">
          {products.cartItems.length > 0 ? (
            products.cartItems.map((product) => {
              // console.log(product.quantity);
              return (
                <div
                  key={product.id}
                  className="w-full pl-20 pr-10 mx-auto flex items-center justify-between py-4  border-b-zinc-300 border-b-2"
                >
                  <div className="flex items-center w-2/4">
                    <div className="h-20 w-20 rounded-sm">
                      <img
                        className="w-full h-full object-contain"
                        src={product.image}
                        alt=""
                      />
                    </div>
                    <h1 className="ml-4">{product.title}</h1>
                  </div>
                  <div className="w-2/4 flex items-center justify-between ">
                    <div className="flex items-center justify-between w-[15%]">
                      <div
                        className="w-5 h-5 shadow-md rounded-full flex items-center justify-center hover:cursor-pointer"
                        onClick={() => decreaseQtyHandle(product)}
                      >
                        -
                      </div>

                      <span>{product.quantity}</span>
                      <div
                        className="w-5 h-5 shadow-md rounded-full flex items-center justify-center hover:cursor-pointer"
                        onClick={() => increaseQtyHandle(product)}
                      >
                        +
                      </div>
                      <ToastContainer />
                    </div>
                    <div className="text-left flex items-center justify-between w-[50%]">
                      <h3>${product.price}</h3>
                      <h3>
                        Total: ${(product.price * product.quantity).toFixed(2)}
                      </h3>
                    </div>
                    <i
                      class="ri-close-line text-3xl hover:cursor-pointer"
                      onClick={() => deleteHandler(product)}
                    ></i>

                    <h3 className="hidden">Total: $</h3>
                  </div>
                </div>
              );
            })
          ) : (
            <h1 className="text-center text-lg mt-10">No items</h1>
          )}
        </div>
        <div className="py-8 min-h-[500px] border-zinc-300 border-2 w-[20%] relative">
          <h1 className="font-medium text-2xl pl-3 mb-2">Summary</h1>
          <hr className="border-t-2 text-zinc-400" />
          <div className="mt-5 absolute bottom-16 px-4 flex items-center justify-between w-full">
            <h2 className="text-xl text-gray-600">Total:</h2>
            <h2 className="text-xl font-medium">${products.priceTotal}</h2>
          </div>
          <button className="mt-5 absolute bottom-0 w-full bg-[#595bdb] text-white py-2 text- duration-200 hover:bg-[#383ab3]">
            Checkout
          </button>
        </div>
      </div>
    </>
  );
};

export default Cart;
