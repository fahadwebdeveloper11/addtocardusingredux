import { createSlice } from "@reduxjs/toolkit"
import { ToastContainer, toast } from 'react-toastify';


const initialState = {
    cartItems: localStorage.getItem("carts") ? JSON.parse(localStorage.getItem("carts")) : [],
    priceTotal: 0
}

export const cartSlice = createSlice({
    name: "cart",
    initialState,
    reducers: {
        addToCart: (state, action) => {
            const itemposition = state.cartItems.findIndex((item) => item.id === action.payload.id)
            if (itemposition >= 0) {
                toast.warning(`${action.payload.title} is already added`, {
                    position: "bottom-left",
                })
            }
            else {
                state.cartItems.push({ ...action.payload, quantity: 1 })
                toast.success(`${action.payload.title} is added`, {
                    position: "bottom-left",
                })
            }
            localStorage.setItem("carts", JSON.stringify(state.cartItems))
        },
        deleteItem: (state, action) => {
            const nextItem = state.cartItems.filter((cart) => cart.id !== action.payload.id)
            state.cartItems = nextItem
            toast.success(`${action.payload.title} is removed`, {
                position: "bottom-left"
            })
            // console.log(nextItem)
            localStorage.setItem("carts", JSON.stringify(state.cartItems))

        },

        increaseQty: (state, action) => {
            const itemIndex = state.cartItems.findIndex((item) => item.id === action.payload.id)
            if (itemIndex >= 0) {
                state.cartItems[itemIndex].quantity += 1
                toast.info(`${action.payload.title} quantity is increased`, {
                    position: "bottom-left"
                })
            }
        },
        decreaseQty: (state, action) => {
            const itemIndex = state.cartItems.findIndex((item) => item.id === action.payload.id)
            if (state.cartItems[itemIndex].quantity > 1) {
                state.cartItems[itemIndex].quantity -= 1
                toast.info(`${action.payload.title} quantity is decreased`, {
                    position: "bottom-left"
                })
            }
        },

        calculateTotal: (state, action) => {
            let { total } = state.cartItems.reduce((cartTotal, cartItem) => {
                const { price, quantity } = cartItem
                const itemTotal = price * quantity
                // console.log(typeof (itemTotal))
                cartTotal.total += itemTotal

                return cartTotal
            }, {
                total: 0
            })
            state.priceTotal = total.toFixed(2)
        }
    }


})

export const { addToCart, deleteItem, increaseQty, decreaseQty, calculateTotal } = cartSlice.actions;
export default cartSlice.reducer;